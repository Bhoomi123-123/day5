package com.quizapplication;

public class Game {

    Question[] questions = new Question[4];
    Player player = new Player();

    String[] questionsdata = {"Who is the most paid member of BTS?", "Who is called Mochi in BTS?", "Who is the most handsome man in world 2020?", "WHo is the all rounder in BTS?"};
    String[] options1 = {"Jhope", "RM", "Jin", "Jimin"};
    String[] options2 = {"V", "Jimin", "Suga", "Jhope"};
    String[] options3 = {"RM", "Jin", "V", "Suga"};
    String[] options4 = {"Jungkook", "Suga", "RM", "Jungkook"};
    int[] answers = {1, 2, 3, 4};

    public void initGame() {
//        created three objects
        for (int i = 0; i < 4; i++) {
            questions[i] = new Question();
        }


        for (int i = 0; i < 4; i++) {

            questions[i].question = questionsdata[i];
            questions[i].option1 = options1[i];
            questions[i].option2 = options2[i];
            questions[i].option3 = options3[i];
            questions[i].option4 = options4[i];
            questions[i].correctAnswer = answers[i];
        }


    }

    public void play() {

        player.getDetails();
        for (int i = 0; i < 4; i++) {
            boolean status = questions[i].askQuestion();
            if (status == true) {
                System.out.println("Well Done your answer is correct!!");
                player.score = player.score + 5;
            } else {
                System.out.println("Oops!! Your answer is wrong");
                player.score = player.score - 5;
            }
        }

        System.out.println(player.name + " your score is " + player.score);


    }

}